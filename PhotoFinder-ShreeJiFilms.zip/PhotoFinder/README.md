# Photo Finder — Shree Ji Films

Starter Android/Expo app connected to the Supabase project URL already established for this project.

## Run
1. Install Node.js.
2. Copy `.env.example` to `.env`.
3. Put your **safe Supabase publishable/anon key** in `.env`. Never put a `service_role`/secret key in this app.
4. Run `npm install` then `npx expo start`.

## Build APK
Install EAS CLI: `npm i -g eas-cli`
Then `eas login` and `eas build -p android --profile preview`.
The preview profile is configured to create an APK.

## Current screens
- Home
- Admin/Photographer login via Supabase Auth
- Events list from `public.events`
- Customer Gallery placeholder

The remaining production modules (photographer creation/temporary access, expiry/revoke, event controls, private photo upload, QR gallery and customer download) can be added to this same project without changing the Supabase project URL.
